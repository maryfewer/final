
var x = 190;
var y = 80;
var z = 210;
var a = 220
var b = 100
var d = 1
var i = 1
var movement 
var move 
var movel 

function setup() {
    createCanvas(400,400);
    movement = Math.floor(Math.random() * 10)+ 1;
    move =Math.floor(Math.random() * 10) + 1;
    movel = Math.floor(Math.random() * 10) + 1;
  }
  
  function draw()
{
    background(220);
    textSize(d);
    text('A Self Portrait', 100, 30);
    
    if(d <= 50)
    {
     d++
    } 
    circle(a,b,70);
    if(a >= 190 || a <= 140)
    {
       move *= -1;
    }

     a += move;
     if(b >= 100 || b <= 70)
     {
        move *= -1;
     }
 
      b += move;
    triangle(165,325,200,125,235,325);
    line(190,180,100,220);
    line(210,180,300,220);
    line(190,325,190,350);
    line(210,325,210,350);
    rect(x,350,15,10);
    if(x >= 190 || x <= 160)
    {
       move *= -1;
    }

     x += move;
    rect(z,350,15,10);
    if(z >= 225 || z <= 195)
    {
       movel *= -1;
    }

     z += movel;
    ellipse(190,y,5,6);
    if(y >= 90 || y <= 70)
    {
       movement *= -1;
    }

     y += movement;
    ellipse(210,y,5,6);
    if(y >= 90 || y <= 70)
    {
       movement *= -1;
    }

     y += movement;
    line(212,100,188,100);
    textSize(15);
    text('Mary Fewer',300,390);
    

    
    
    

}