function setup() {
    createCanvas(400,400);
  }
  
  function draw()
{
    background(220);
    textSize(32);
    text('A Self Portrait', 100, 30);
    circle(200,90,70);
    triangle(165,325,200,125,235,325);
    line(190,180,100,220);
    line(210,180,300,220);
    line(190,325,190,350);
    line(210,325,210,350);
    rect(175,350,15,10);
    rect(210,350,15,10);
    ellipse(190,80,5,6);
    ellipse(210,80,5,6);
    line(212,100,188,100);
    textSize(15);
    Point(14,80)
    text('Mary Fewer',300,390)
    
    
    

}