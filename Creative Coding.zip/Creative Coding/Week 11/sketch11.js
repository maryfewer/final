  var x = Math.floor(Math.random() * 800);
  var y = Math.floor(Math.random()*600);
  var v = Math.floor(Math.random() * 800);
  var w = Math.floor(Math.random() * 600);
  var t = Math.floor(Math.random() * 800);
  var u = Math.floor(Math.random() * 600);
  var a = 25
  var b = 25
  var value =0
  var value2 = 0
    
    function setup()
    {
        createCanvas(800,600);
    }
    function draw()
    {
        background(0);
        fill(value2)
        text('You win!', 400,300)
        fill(24,200,29);
        circle(x,y,25);
        if (x < 800){
          x+=1;
        }
        else {
          x=0;
          y = Math.floor(Math.random()*600);
        }
        fill(30,30,255)
        circle(v,w,100);
        if (v < 800){
          v+=2;
        }
        else {
          v=0;
          w = Math.floor(Math.random()*600);
        }
        fill(255,0,29);
        circle(t,u,40);
        if (u < 600){
          u+=3;
        }
        else {
          u=0;
          t = Math.floor(Math.random()*800);
        }
        fill(value);
         circle(a,b,50);
        if (a > 775 || a < 0){
          a = 25;
        }
        if (b > 575 || a < 0){
          b=25;
        }
        if(a > 755 && b > 500)
        {
          value2 = 255
        }
        fill(255,255,255)
        rect(780,520,20,80)
        
      }
    function mouseClicked()
    {
      value = 255
    }
    function keyPressed() 
    {
      if (key == 'd') 
      {
        a+=15;
      } 
      else if (key == 'a') 
      {
        a-=15;
      }
      else if (key == 's') 
      {
        b+=15;
      }
      else if (key == 'w') 
      {
        b-=15;
      }

    }